#----------------------------------------
# Tablas (dataframes)
#----------------------------------------

#----------------------------------------
## Inspección de una tabla
#----------------------------------------

iris

print(iris)

plot(iris)       # la representa gráficamente

# Trata de interpretar el gráfico generado con `plot(iris)`. ¿Qué nos dice, p.e., de 
# la relación entre la anchura y la longitud de los pétalos?

# Trata de intepretar la salida del resto de las anteriores líneas de código. ¿Qué 
# nos dicen del conjunto de datos?

head(iris)    # primeras seis filas

?summary

# Consulta la ayuda de la función `head` y averigua cómo mostrar las diez primeras 
# filas de `iris` en lugar de las seis que aparecen por defecto.

dim(iris)     # filas x columnas

colnames(iris)  

# Consulta el tamaño, número de filas y el número y nombre de las columnas del conjunto 
# de datos `airquality`; muestra también las primeras 13 filas de esa tabla.

# Examina el conjunto de datos `attenu`. Consulta su ayuda (`?attenu`) para averiguar 
# qué tipo de información contiene. Finalmente, usa `summary` para ver si contiene 
# algún nulo en alguna columna.

# Haz una lista con todas las funciones que aparecen nombradas en esta sección y trata 
# de recordar lo que hace cada una de ellas.

#----------------------------------------
## Selección de filas y columnas
#----------------------------------------

iris[1:10,]        # diez primeras filas

iris[, "Species"] 

iris$Species

# R está diseñado fundamentalmente para ser usado interactivamente, es decir, para 
# que el usuario utilice la consola para ensayar, probar distintas alternativas, etc. 
# Por eso R está lleno de _atajos_ pensados para abreviar el trabajo, dispone de operadores 
# flexibles como los corchetes, etc. Eso lo diferencia de otros lenguajes, frecuentemente 
# mucho más rígidos, que están orientados a crear programas más o menos complejos.

iris[iris$Species == "setosa",]

# Selecciona las filas de `iris` cuya longitud del pétalo sea mayor que 4.

# Selecciona las filas donde `cyl` sea menor que 6 y `gear` igual a 4 en `mtcars`. 
# Nota: el operador `AND` en R es `&`.

# La selección de filas mediante condiciones lógicas es muy útil y será muy necesaria 
# posteriormente cuando queramos eliminar sujetos con edades negativas, detectar los 
# pacientes con niveles de glucemia por encima de un determinado umbral, etc.

#----------------------------------------
## Creación y eliminación de tablas y columnas
#----------------------------------------

mi.iris <- iris  # mi.iris es una copia de iris

# Los nombres de objetos siguen las reglas habituales en otros lenguajes de programación: 
# son secuencias de letras y números (aunque no pueden comenzar por un número) y se 
# admiten los separadores `_` y `.`: tanto `mi.iris` como `mi_iris` son nombres válidos. 
# Hay quienes prefieren usar _camel case_, como `miIris`. Es cuestión de estilo; y, 
# en cuestiones de estilo, todo es discutible salvo la consistencia.

ls()         # lista de objetos en memoria

mi.iris <- iris

# Crea una copia del conjunto de datos `airquality`. Comprueba con `ls` que está efectivamente 
# creado y luego añádele una columna nueva llamada `temperatura` que contenga una copia 
# de `Temp`. Comprueba que efectivamente está allí y luego, elimínala. Finalmente, 
# borra la tabla.

# Usando el conjunto de datos `CO2`, selecciona los valores en los que el tratamiento 
# sea `chilled`, y el valor de `uptake`, mayor que 15; devuelve únicamente las 10 primeras 
# filas.

#----------------------------------------
## Ordenación
#----------------------------------------

mi.iris <- iris[order(iris$Petal.Length),]

# Verifica que `mi.iris <- iris[order(-iris$Petal.Length),]` ordena decrecientemente.

# Crea una versión de `iris` ordenando por especie y dentro de cada especie, por `Petal.Length`. 
# Ten en cuenta que en R se puede ordenar por dos o más columnas porque `order` admite 
# dos o más argumentos (véase `?order`). Por ejemplo, `iris[order(iris$Petal.Length, 
# iris$Sepal.Length),]` deshace los empates en `Petal.Length` de acuerdo con `Sepal.Length`. 


# Encuentra el día más frío de los que contiene `airquality`.

# Usando el mismo conjunto de datos, encuentra el día más caluroso del mes de junio.

#----------------------------------------
## Lectura de datos externos
#----------------------------------------

getwd()         

datos <- read.table("data_dir/mi_fichero.csv", sep = "\t", header = TRUE)

# Lee el fichero `paro.csv` usando la función `read.table`. Comprueba que está correctamente 
# importado usando `head`, `tail`, `nrow`, `summary`, etc. Para leer la tabla necesitarás 
# leer con cierto detenimiento `?read.table`.

# Repite el ejercicio anterior eliminando la opción `header = TRUE`. Examina el resultado 
# y comprueba que, efectivamente, los datos no se han cargado correctamente.

# Lee algún fichero de datos de tu interés y repite el ejercicio anterior.

# En `read.table` y sus derivados puedes indicar, además de ficheros disponibles en 
# el disco duro, la URL de uno disponible en internet. Prueba a leer directamente el 
# fichero disponible en `https://datanalytics.com/uploads/datos_treemap.txt`. Nota: 
# es un fichero de texto separado por tabuladores y con nombres de columna.

# Alternativamente, si quieres leer un fichero remoto, puedes descargarlo directamente 
# desde R. Consulta la ayuda de `download.file` para bajarte al disco duro el fichero 
# del ejercicio anterior y leerlo después.

#----------------------------------------
## Gráficos básicos
#----------------------------------------

#----------------------------------------
### Gráficos de dispersión
#----------------------------------------

plot(cars$speed, cars$dist)

# Representa gráficamente la anchura del sépalo contra su longitud (en `iris`).

plot(cars$dist, main = "Distancias de...", 

# Consulta la ayuda de la función `abline` y úsala para añadir líneas a alguno de los 
# gráficos anteriores.

# Consulta `?par`, una página de ayuda en R que muestra gran cantidad de parámetros 
# modificables en un gráfico. Investiga y usa `col`, `lty` y `lwd`. Nota: casi nadie 
# conoce estos parámetros y, menos, de memoria; pero está bien saber que existen por 
# si un día procede utilizarlos.

#----------------------------------------
### Gráficos de barras
#----------------------------------------

barplot(VADeaths[, 2], xlab = "tramos de edad", ylab = "tasa de mortalidad", 

# Mejora el gráfico anterior con el parámetro `col` (de color).

dotchart(t(VADeaths),  main = "Death Rates in Virginia - 1940", cex = 0.8)

# Los gráficos de barras exigen como parámetros o bien un vector o bien una matriz. 
# En el primer ejemplo hemos usado como vector una columna de una matriz; en el segundo, 
# una matriz completa (y la función de trasposición `t`).

# La diferencia más importante entre las tablas y las matrices es que las últimas contienen 
# datos de un mismo tipo (casi siempre, números), mientras que las tablas pueden mezclar 
# columnas numéricas y no numéricas. En R se pueden realizar operaciones típicas de 
# álgebra lineal (multiplicación matricial, matrices inversas, valores y vectores propios, 
# etc.) operando, obviamente, sobre matrices.

#----------------------------------------
### Histogramas
#----------------------------------------

hist(iris$Sepal.Width)

# Estudia la distribución de las temperaturas en Nueva York (usa `airquality`).

# Usa `col` para mejorar el aspecto del gráfico. Añádele un título y una etiqueta en 
# el eje horizontal.

# Usa `abline` para dibujar una línea vertical roja en la media de la distribución. 
# Puedes obtener la media con `summary` o bien aplicando la función `mean` a la columna 
# de interés.

#----------------------------------------
### Diagramas de caja (boxplots)
#----------------------------------------

boxplot(iris$Sepal.Width ~ iris$Species, col = "gray",

# Muestra la distribución de las temperaturas en Nueva York en función del mes.

#----------------------------------------
## Resumen y referencias
#----------------------------------------

#----------------------------------------
## Ejercicios adicionales
#----------------------------------------

# Estudia el conjunto de datos `airquality` (información meteorológica de ciertos meses 
# de cierto año en Nueva York, que también viene _de serie_ en R) aplicando las funciones 
# anteriores. En particular, responde las preguntas

# * ¿cuál es la temperatura media de esos días?
# * ¿cuál es la temperatura media en mayo?
# * ¿cuál fue el día más ventoso?

# Crea una tabla adicional seleccionando todas las columnas menos mes y día; luego 
# haz un `plot` de ella y trata de encontrar relaciones (cualitativas) entre la temperatura 
# y el viento, o el ozono,...

# Usando el conjunto de datos `mtcars` (consulta `?mtcars`), averigua:

# * cuál es el modelo que menos consume
# * cuál es el consumo medio de los modelos de 4 cilindros


#----------------------------------------
# Introducción a la estadística con R
#----------------------------------------

#----------------------------------------
## El test de Student
#----------------------------------------

summary(sleep)

boxplot(sleep$extra ~ sleep$group, col = "gray", 

t.test(sleep$extra ~ sleep$group)

# El test de Student no se puede aplicar a cualquier tipo de datos. Estos tienen que 
# cumplir una serie de condiciones. Cuando las pruebas previas parecen indicar que 
# no dichas condiciones no se cumplen, los manuales recomiendan utilizar una alternativa 
# no paramétrica, la del Wilcoxon. Aplícasela a estos datos comprueba el p-valor obtenido. 
# Nota: en R, es el `wilcox.test`.

# Estudia los ejemplos de `prop.test`, que implementa una prueba estadística para comprobar 
# si dos proporciones son o no _significativamente distintas_.

#----------------------------------------
## Regresión lineal
#----------------------------------------

plot(cars$speed, cars$dist)

lm.dist.speed <- lm(cars$dist ~ cars$speed)

summary(lm.dist.speed)

plot(lm.dist.speed, 1)

# Haz una regresión del nivel de ozono sobre la temperatura en Nueva York. Crea el 
# gráfico de dispersión y añádele la recta de regresión (en rojo u otro color distinto 
# del negro) con `abline`.

#----------------------------------------
## Regresión logística
#----------------------------------------

datos <- as.data.frame(UCBAdmissions)

modelo.sin.dept <- glm(Admit ~ Gender, 

modelo.con.dept <- glm(Admit ~ Gender + Dept, 

# El primer modelo, esencialmente, compara dos proporciones: el de hombres y mujeres 
# admitidos. Utiliza la prueba de proporciones (`prop.test` en R) para compararlas 
# de otra manera. ¿Coinciden los resultados?

#----------------------------------------
## Resumen y referencias
#----------------------------------------

#----------------------------------------
## Ejercicios adicionales
#----------------------------------------


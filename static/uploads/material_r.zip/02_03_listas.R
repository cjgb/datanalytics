#----------------------------------------
# Listas
#----------------------------------------

#----------------------------------------
## Algunos usos de las listas
#----------------------------------------

is.list(iris)

datos <- as.data.frame(UCBAdmissions)

is.list(modelo.con.dept)

# Explora `modelo.con.dept` con las funciones `names` y `str`.

# Guarda la salida del test de Student de la sección anterior como un objeto. ¿De qué 
# clase es? Examínalo con las funciones anteriores.

#----------------------------------------
## Exploración y manipulación de listas
#----------------------------------------

length(iris)

modelo.con.dept$coefficients

mi.lista <- list(a = 1:3, b = c("hola", "adiós"))

# ¿Qué función serviría para concatenar dos listas? ¿Puedes poner un ejemplo?

# ¿Cómo borrarías un elemento de una lista? Recuerda cómo se hacía con tablas (que 
# no dejan de ser listas).

# ¿Qué crees que pasaría si haces `mi.lista[1:2]`?

# Compara `mi.lista[2]` y `mi.lista[[2]]`. ¿Cuál es la diferencia?

# ¿Cómo se crea una lista vacía?

# Si escribes `lm` en la consola de R, se muestra el código de dicha función. Hazlo 
# y examina la última parte. Comprueba que no hace otra cosa que añadir progresivamente 
# elementos a una lista, la que define el modelo, para devolverla al final.

#----------------------------------------
## Las funciones lapply, sapply y split
#----------------------------------------

lapply(airquality[, 1:4], mean, na.rm = TRUE)

sapply(airquality[, 1:4], mean, na.rm = TRUE)

sqrt(1:5)

sapply(1:5, sqrt)

tmp <- split(iris, iris$Species)

# Investiga el objeto `tmp`: ¿qué longitud tiene? ¿qué contiene cada uno de sus componentes?

# Usa las funciones `lapply` y `sapply` para mostrar la dimensión de cada una de las 
# tablas que contiene `tmp`.

# Usa `split` para partir `iris` en dos subtablas al azar con el mismo número de filas. 


# Usa `split` para partir `iris` cinco subtablas, cada una de ellas con 30 filas distintas.

#----------------------------------------
## Resumen y referencias
#----------------------------------------

#----------------------------------------
## Ejercicios adicionales
#----------------------------------------

# La función `strsplit` parte una cadena de texto por un caracter o conjunto de caracteres. 
# Explora la salida de `strsplit(c("un día vi", "una vaca vestida de uniforme"), " 
# ")`.

# Dada la lista `mi.lista <- list(a = 1:3, b = c("hola", "adiós"))`, 

# - suma los elementos de su primera componente
# - añade a su segundo elemento el valor `hasta luego`
# - usa `lapply` o `sapply` para calcular la longitud de cada elemento de la lista
# - añade a la lista un tercer elemento (llamado `iris`) que contenga la tabla `iris`
# - borra el elemento `a`


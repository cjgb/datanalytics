#----------------------------------------
# Vectores
#----------------------------------------

#----------------------------------------
## Creación de vectores
#----------------------------------------

x <- 1:10

# Crea el vector que numera las filas de iris (es decir, que contenga los números del 
# 1 hasta el número de filas de `iris`). Nota: este es un ejercicio muy importante 
# sobre el que abundaremos más adelante.

1:5

seq(1, 4)

rep(1:4, 4)

# Crea el patrón 1, 1.1, 1.2,..., 2. Existen varias maneras de hacerlo. Una de ellas 
# es utilizar el argumento `by` de `seq`.

rep(1:4, 2) 

# Selecciona las columnas 1, 2 y 5 de `iris`.

# Selecciona las filas `1:4` y `100:104` de `iris`.

# Usa un vector de texto para seleccionar las columnas `Wind` y `Temp` de `airquality`.

# Crea una tabla que sea la primera fila de `iris` repetida 100 veces. 

#----------------------------------------
## Inspección de vectores
#----------------------------------------

plot(x)

table(iris$Species)

# En `CO2`, cuenta cuántas filas corresponden a cada tipo de planta. 

# Ejecuta e interpreta `table(table(CO2$conc))`. Nota: `table(table(x))` es una operación 
# muy frecuente y útil.

#----------------------------------------
## Selecciones
#----------------------------------------

x <- x^2

# Selecciona todos los elementos de un vector menos menos los dos últimos.

# Implementa la función `diff` (las diferencias entre cada valor de un vector y el 
# que lo precede) a mano. Nota: la función `diff` existe en R; pruébala en caso de 
# duda.

z <- 1:10 

mi.iris <- iris   # una copia de iris

# Cambia (en una sola expresión) los nombres de las dos primeras columnas de `mi.iris` 
# por su traducción al español.

sample(x, 4) 

# Muestrea `iris`, es decir, extrae (p.e., 30) filas al azar de dicha tabla. Pista: 
# recuerda que _ordenar_ era _seleccionar ordenadamente_; de igual manera, en una tabla, 
# muestrear será...

# En una provincia la población activa es de un millón de personas. El 10% de ellas 
# está en el paro. Periódicamente el INE hace una encuesta sobre 1000 personas para 
# estimar la tasa de paro. Pero esta encuesta, por estar basada en 1000 personas, está 
# sujeta a error. Puedes tratar de medir ese error de la siguiente manera: crea un 
# vector de longitud 1M con cien mil valores iguales a 1 y el resto, a 0. Extrae una 
# muestra de tamaño 1000 y calcula la proporción de unos. ¿Está cerca del 10%? 

# Repite el ejercicio anterior varias veces. ¿Cómo varían las estimaciones? ¿Qué pasa 
# si encuestas a 10000 personas en lugar de a 1000? ¿Y si encuestas a 100?

# Lee la parte relevante de `?replicate`. ¿Para qué sirve esta función? ¿Puede ser 
# útil para analizar el caso propuesto en los ejemplos anteriores? Nota: la página 
# de ayuda de la función anterior documenta varias funciones relacionadas, pero puedes 
# ignorar por el momento todo lo que no se refiera a la función en cuestión.

# Parte `iris` en dos partes iguales (75 observaciones cada uno) con las filas elegidas 
# al azar (¡y complementarias!).

# Ejecuta `mean(sample(iris$Sepal.Length, replace = T))` varias veces. Comprueba que 
# obtienes números que se parecen a la media de `iris$Sepal.Lenght`. Nota: esto es 
# el fundamento de una técnica estadística muy poderosa, el [_bootstrap_](https://en.wikipedia.org/wiki/Bootstrapping_(statistics)), 
# para estimar cómo puede variar una media (i.e., estimar la varianza de una media).

#----------------------------------------
## Distribuciones de probabilidad
#----------------------------------------

x.uniforme <- runif(10)

# Casi todas las distribuciones admiten parámetros adicionales. Por ejemplo, la media 
# y la desviación estándar para la distribución normal. Consulta la ayuda de `rnorm` 
# para ver cómo muestrear una variable aleatoria normal con media 1 y desviación estándar 
# 3. Extrae una muestra del 10000 elementos de ella y comprueba que lo has hecho correctamente 
# usando las funciones `mean` y `sd`.

hist(rnorm(1000))

# Busca cómo muestrear la distribución gamma.

# Consulta la ayuda de `rnorm`, `runif` y  `rpois`. ¿Qué tienen en común?

curve(dnorm(x, 0, 2), -8, 8)

# Usa `curve` para representar la densidad de la distribución beta para diversos valores 
# de sus parámetros. Lee `?curve` para averiguar cómo sobreimpresionar curvas y representa 
# la densidad para diversas combinaciones de los parámetros con colores distintos. 
# Puedes comparar el resultado con los gráficos que aparecen en la página de la distribución 
# beta en la Wikipedia.

curve(pnorm(x, 0, 2), -8, 8)

curve(dnorm(x, 0, 2), -8, 8)

#----------------------------------------
## Ordenación
#----------------------------------------

x <- c(4, 5, 3, 2, 1, 2)

x

rank(x)

# `rank(x)` es una transformación no lineal de `x` que puede ser útil para normalizar 
# datos en algunos contextos.

# Si `x` contuviese el número de puntos obtenidos en la liga de fútbol por los distintos 
# equipos, ¿cómo usarías `rank` para determinar cuál es el campeón?

# ¿Qué otros tipos de _ties_ existen? ¿Qué hacen?

# Comprueba que `rank(x, ties = 'first')` es equivalente a `order(order(x))`.

# Comprueba que `order(order(order(x)))` es equivalente a `order(x)`.

# Ejecuta e interpreta `tail(sort(table(CO2$uptake)))`. ¿Qué utilidad le ves a la expresión 
# anterior?

#----------------------------------------
## Operaciones matemáticas y vectorización
#----------------------------------------

2+2

c(length(2), length(x))

x <- 1:10

# Comprueba que `log` es una función vectorizada aplicándosela a `x`.

# Calcula el valor medio de la longitud de los pétalos de `iris` usando `mean`.

# Repite el ejercicion anterior usando `sum` y `length`.

# Suma un millón de términos de la [fórmula de Leibniz](http://en.wikipedia.org/wiki/Leibniz_formula_for_%CF%80)] 
# para aproximar $\pi$. Pista: crea primero un vector con los índices (del 0 al 1000000) 
# y transfórmalo adecuadamente. 

# Si `x <- 1:10` e `y <- 1:2`, ¿cuánto vale `x * y`? ¿Qué pasa si `y <- 1:3`? 

#----------------------------------------
## Digresión: una calculadora de hipotecas con R
#----------------------------------------

1000 * (1 + 3 / 100)^4

1000 / (1 + 3 / 100)^4

interes.mensual <- 3 / 12 / 100

capital <- 100000 

#----------------------------------------
## Digresión: creación de funciones
#----------------------------------------

fivenum(x)   # los "cinco números característicos" de un vector 

x <- 1:10

# Si no existiese `prod` se podría programar: usa `log`, `exp` y `sum` para crear una 
# función, `mi.prod` que multiplique los elementos de un vector (de números, por el 
# momento, $> 0$).

# Crea una función que cuente el número de valores negativos (<0) del vector que se 
# le pase como argumento.

media <- function(x){

#----------------------------------------
## La función tapply
#----------------------------------------

tapply(iris$Petal.Length, iris$Species, mean)

# Calcula el valor medio de la temperatura en cada mes de Nueva York (usando `airquality`).

tapply(iris$Petal.Length, iris$Species, mean, na.rm = TRUE)

foo <- function(x) mean(x, na.rm = TRUE)

# Calcula el valor medio del ozono en cada mes de Nueva York (usando `airquality`).

# Usando `mtcars`, calcula la potencia mediana según el número de cilindros del vehículo.

#----------------------------------------
## Resumen y referencias
#----------------------------------------

#----------------------------------------
## Ejercicios adicionales
#----------------------------------------


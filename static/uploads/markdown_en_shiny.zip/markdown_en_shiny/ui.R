library(shiny)

# Define UI for application that draws a histogram
shinyUI(fluidPage(
  
  # Application title
  titlePanel("Hello Shiny!"),
  
  # Sidebar with a slider input for the number of bins
  sidebarLayout(
    sidebarPanel(
      radioButtons("radio", 
                   label = h3("Radio buttons"),
                   choices = list("Choice 1" = 1, 
                                  "Choice 2" = 2,
                                  "Choice 3" = 3),
                   selected = 1)
    ),
    
    # Show a plot of the generated distribution
    mainPanel(
      htmlOutput("myrmd")
    )
  )
))
library(shiny)
library(rmarkdown)

# Define server logic required to draw a histogram
shinyServer(function(input, output) {
  
  # Expression that generates a histogram. The expression is
  # wrapped in a call to renderPlot to indicate that:
  #
  #  1) It is "reactive" and therefore should be automatically
  #     re-executed when inputs change
  #  2) Its output type is a plot
  
  output$myrmd <- renderText({
    parametro.0 <- input$radio
    save(parametro.0, file = "rmd_config.Rdat")
    render("sample_rmarkdown.Rmd", output_file = "sample_rmarkdown.html")
    readLines("sample_rmarkdown.html")
    
  })
  
})
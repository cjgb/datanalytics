##########################################################
# cjgb@datanalytics.com
# 20110709
# Simulaci'on del n'umero de ciudadanos k-an'onimos a nivel nacional
#	en los tres intervalos temporales para las fechas de nacimiento:
#	dd-mm-aa, mm-aa, aa
# La simulaci�n puede tardar varias horas.
# Por eso, los datos de salida se guardan en ficheros que son
#	le�dos m�s tarde.
##########################################################


indices <- as.integer( ( rep( 1:nrow( total ), times = total$n ) - 100000 ) * 10000 )

foo <- function( file = "/tmp/borrar.txt", lustro = lustro, indices = indices, iter ){
    x <- sort( indices + sample( lustro, length( indices ), replace = T ) )

    n <- length(x)
    y <- x[-1L] != x[-n]
    rm( x )
    gc()
    x <- sort( diff( c( 0L, c(which(y), n) ) ) )

    res <- rle( x )
    rm( x ); gc()
    # res <- data.frame( res$values, res$lengths )
    cat( paste( paste( rep( iter, length( res$values ) ), res$values, res$length, sep = " " ), collapse = "\n" ), file = file, append = T )
    cat( "\n",                                                                                                    file = file, append = T )
}

for( i in 1:2000 ) foo( file = "../dat/mc_day.txt",   lustro = 365 * 5 + 1, indices = indices, iter = i )
for( i in 1:2000 ) foo( file = "../dat/mc_month.txt", lustro = 12 * 5,      indices = indices, iter = i )
for( i in 1:2000 ) foo( file = "../dat/mc_year.txt",  lustro = 5,           indices = indices, iter = i )


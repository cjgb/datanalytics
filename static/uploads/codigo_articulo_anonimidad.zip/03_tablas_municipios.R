############################################################################
# Crea las tablas en una selecci�n de municipios
# cjgb, 201108
# Las tablas necesitan ciertos retoques est�ticos manuales despu�s de ser generadas
#	con R en formato LaTeX.
############################################################################

# La selecci�n de municipios se hizo originalmente ejecutando
#	seleccion <- sort( sample( rownames( tmp ), 20, replace = F, tmp$total ) )

seleccion <- c( "02003-Albacete", "03014-Alicante/Alacant", "04013-Almer�a", "06160-Zalamea de la Serena", "07058-Selva", "08019-Barcelona", "08099-Guardiola de Bergued�", "08123-Molins de Rei", "08279-Terrassa", "22233-Torre la Ribera", "23070-Pozo Alc�n", "28079-Madrid", "29025-Benalm�dena", "30041-Uni�n (La)", "33024-Gij�n", "33044-Oviedo", "33066-Siero", "45165-Talavera de la Reina", "48020-Bilbao", "50297-Zaragoza" )

#
# Dependiendo del "encoding" de la plataforma en que se ejecuta el programa, puede que caracteres no ASCII se codifiquen de otra manera.
# Por referencia, dejo aqu� comentada el mismo vector con un "encoding" distinto.

#seleccion <- c( "02003-Albacete", "03014-Alicante/Alacant", "04013-Almería", "06160-Zalamea de la Serena", "07058-Selva", "08019-Barcelona", "08099-Guardiola de Berguedà", "08123-Molins de Rei", "08279-Terrassa", "22233-Torre la Ribera", "23070-Pozo Alcón", "28079-Madrid", "29025-Benalmádena", "30041-Unión (La)", "33024-Gijón", "33044-Oviedo", "33066-Siero", "45165-Talavera de la Reina", "48020-Bilbao", "50297-Zaragoza" )

# k-anonimidad por municipio a diversos niveles

grados.x.municipio <- function( lustro, grados ){
	tmp <- sapply( unique( total$municipio ), k.municipio, lustro, grados )
	tmp <- t( tmp )
	tmp <- round( tmp )
	tmp <- data.frame( tmp )
	rownames( tmp ) <- unique( total$municipio )
	colnames( tmp ) <- c( grados, "total" )
	tmp
}

rangos <- list( 1, 2,3,4,5,6:10,11:20,21:50, 51:100 )
grados <- unlist( rangos )
grados <- min( grados ):max( grados )

tmp.day   <- grados.x.municipio( 5 * 365, grados )
tmp.month <- grados.x.municipio( 5 *  12, grados )
tmp.year  <- grados.x.municipio( 5 *   1, grados )


agrega.rangos <- function( tabla, municipio ){
    tmp <- tabla[ rownames( tabla ) == municipio, ]
	tmp <- colSums( tmp )
	res <- lapply( rangos, function( x ) sum( tmp[x] ) )
	res <- c( unlist( res ), tmp[101] - sum( tmp[-101] ), tmp[101] )
    names( res ) <- NULL
    res
}

#res.tabla1.day   <- foo( tmp.day )
#res.tabla1.month <- foo( tmp.month )
#res.tabla1.year  <- foo( tmp.year )

foo.tabla <- function( tabla ){
    tmp.tabla <- as.data.frame( t( sapply( seleccion, function( muni ) agrega.rangos( tabla, muni ) ) ) )
    tmp.tabla <- tmp.tabla[ order( -tmp.tabla[ , ncol( tmp.tabla ) ] ), ]
    xtable( tmp.tabla, digits = 0 )
}

foo.tabla( tmp.day )
foo.tabla( tmp.month )
foo.tabla( tmp.year )


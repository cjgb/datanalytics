##########################################################
# cjgb@datanalytics.com
# 20110709
# Simulaci'on del n'umero de ciudadanos k-an'onimos a
#   nivel nacional
##########################################################

rangos <- data.frame( inicio = c( 1, 2,3,4,5,6,11,21, 51 ), fin = c( 1, 2,3,4,5,10,20,50, 999999 ) )

dat.day   <- read.table( "../dat/mc_day.txt", header = F )
dat.month <- read.table( "../dat/mc_month.txt", header = F )
dat.year  <- read.table( "../dat/mc_year.txt", header = F )

aggr.table <- function( tabla, rangos ){
    rangos <- cut( tabla$V2, breaks = c( -Inf, rangos$fin ), right = T ); gc()
    iter <- as.integer( tabla$V1 )
    n    <- as.integer( tabla$V2 * tabla$V3 )

    gc();

    foo <- function( rango ){
         print( rango ); flush.console()
         mi.rango <- rangos == rango

         mi.n <- n[ mi.rango ]; gc()
         mi.iter <- iter[ mi.rango ]; gc()

         tmp <- rep( 0, max( mi.iter ) )

         for( i in 1:length( mi.n ) )
              tmp[ mi.iter[i] ] <- tmp[ mi.iter[i] ] + mi.n[ i ]

         rm( mi.rango, mi.n, mi.iter ); gc()
         tmp <- quantile( tmp, c(0.025, 0.5, 0.975 ))
         salida <- list()
         salida$pct      <- 100 * tmp[2] / sum( total$n )
         salida$mediana  <- tmp[2]
         salida$int.conf <- ( tmp[3] - tmp[1] ) / 2
         rm( tmp ); gc()
         unlist( salida )
    }

    as.data.frame( t( sapply( levels( rangos ), foo ) ) )
}

# debug( aggr.table )
t.day <- aggr.table( dat.day, rangos )
t.month <- aggr.table( dat.month, rangos )
t.year <- aggr.table( dat.year, rangos )

tmp <- cbind( t.day, t.month, t.year )
xtable( tmp )


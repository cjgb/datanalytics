############################################################################
# Crea la gr�fica del art�culo
# cjgb, 201108
############################################################################

# requiere que se haya ejecutado previamente el programa 00_*.R

calcular.k.anon <- function( lustro, grados ){
    tmp <- sapply( unique( total$municipio ), k.municipio, lustro, grados )
    tmp <- t( tmp )
    tmp <- round( tmp )
    tmp <- data.frame( tmp )
    rownames( tmp ) <- unique( total$municipio )
    colnames( tmp ) <- c( grados, "total" )
    tmp
}

tmp.day   <- calcular.k.anon( 5 * 365, 1 )	# en un lustro hay 5 * 365 d�as y s�lo nos interesa la 1-anonimidad
tmp.month <- calcular.k.anon( 5 *  12, 1 )	# 60 meses...
tmp.year  <- calcular.k.anon( 5 *   1, 1 )


postscript( "grafico_conjunto.eps", width = 10, height = 10 )

	plot( log10(tmp.day$total), 100 * tmp.day[,1] / tmp.day$total, 
	    pch = ".", 
	    xlab = "Logaritmo de la poblaci�n del municipio", 
	    ylab = "% de 1-anonimidad", 
	    main = "Porcentaje de 1-anonimidad en funci�n del tama�o del municipio" ,
	    col = "black"
	)

	points( log10(tmp.month$total), 100 * tmp.month[,1] / tmp.month$total, pch = ".", col = "red" )
	points( log10(tmp.year$total), 100 * tmp.year[,1] / tmp.year$total, pch = ".", col = "blue" )

	grid()
	legend( x = "topright", legend = c( "aa-mm-dd", "aa-mm", "aa" ), fill = "white", border = "white", text.col = c( "black", "red", "blue") )

dev.off()



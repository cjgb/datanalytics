########################################
# Carga de datos y funciones auxiliares
# cjgb, 201108
########################################

library( pxR )
library( xtable )

province.numbers <- sapply( 1:52, function( x ) sprintf( "%05d", x ) )
province.numbers <- paste( "http://www.ine.es/pcaxisdl//t20/e245/p05/a2010/l0/", province.numbers, "001.px", sep = "" )

res <- sapply( province.numbers, function( x ) as.data.frame( read.px( url( x ) ) ), simplify = F )


total <- do.call( rbind, res )

rm( res, province.numbers ); gc()

colnames( total ) <- c( "edad", "municipio", "sexo", "n" )
rownames( total ) <- NULL

total <- subset( total, n > 0 )			# borra celdas vac�as

total <- subset( total, edad != "Total" )
total$edad <- factor( total$edad )

total <- subset( total, sexo != "Ambos sexos" )
total$sexo <- factor( total$sexo )

total <- subset( total, municipio != "Total" )
total$municipio <- factor( total$municipio )

gc()


### funciones auxiliares ###

# n'umero promedio de periodos con k nacimientos cuando la poblaci'on total es n y el de periodos, N

knon <- function( k, n, N ){
    dbinom( k, n, 1 / N ) * k * N
}

# n'umero promedio de ciudados k-an'onimos por municipio, donde k %in% grados

k.municipio <- function( mi.municipio, lustro, grados ){
    enes <- subset( total, municipio == mi.municipio )$n
    # tmp <- sapply( grados, function( k ) sum( sapply( enes, function( n ) knon( k, n, lustro ) ) ) )
    tmp <- sapply( grados, function( k ) sum( knon( k, enes, lustro ) ) )
    tmp <- c( tmp, sum( enes ) )
    tmp
}

# municipios seleccionados para las tablas

# seleccion <- sort( sample( rownames( tmp ), 20, replace = F, tmp$total ) ); seleccion
# > seleccion
# [1] "02003-Albacete"                 "03014-Alicante/Alacant"        
# [3] "04013-Almería"               "06160-Zalamea de la Serena"    
# [5] "07058-Selva"                    "08019-Barcelona"               
# [7] "08099-Guardiola de Bergued\340" "08123-Molins de Rei"           
# [9] "08279-Terrassa"                 "22233-Torre la Ribera"         
# [11] "23070-Pozo Alc\363n"            "28079-Madrid"                  
# [13] "29025-Benalm\341dena"           "30041-Uni\363n (La)"           
# [15] "33024-Gij\363n"                 "33044-Oviedo"                  
# [17] "33066-Siero"                    "45165-Talavera de la Reina"    
# [19] "48020-Bilbao"                   "50297-Zaragoza"            

#seleccion <- c( "02003-Albacete", "03014-Alicante/Alacant", "04013-Almería", "06160-Zalamea de la Serena", "07058-Selva", "08019-Barcelona", "08099-Guardiola de Berguedà", "08123-Molins de Rei", "08279-Terrassa", "22233-Torre la Ribera", "23070-Pozo Alcón", "28079-Madrid", "29025-Benalmádena", "30041-Unión (La)", "33024-Gijón", "33044-Oviedo", "33066-Siero", "45165-Talavera de la Reina", "48020-Bilbao", "50297-Zaragoza" )

#seleccion <- c( "02003-Albacete", "03014-Alicante/Alacant", "04013-Almer�a", "06160-Zalamea de la Serena", "07058-Selva", "08019-Barcelona", "08099-Guardiola de Bergued�", "08123-Molins de Rei", "08279-Terrassa", "22233-Torre la Ribera", "23070-Pozo Alc�n", "28079-Madrid", "29025-Benalm�dena", "30041-Uni�n (La)", "33024-Gij�n", "33044-Oviedo", "33066-Siero", "45165-Talavera de la Reina", "48020-Bilbao", "50297-Zaragoza" )


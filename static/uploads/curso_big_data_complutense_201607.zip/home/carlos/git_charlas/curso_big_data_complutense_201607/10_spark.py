#---------------------------------------------------------------------
# calcular pi
#---------------------------------------------------------------------

from random import random

num_muestras = 100000

def sample(p):
    x, y = random(), random()
    return 1 if x*x + y*y < 1 else 0

count = sc.parallelize(xrange(0, num_muestras)).map(sample).reduce(lambda a, b: a + b)

print "Pi es aproximadamente %f" % (4.0 * count / num_muestras)


#---------------------------------------------------------------------
# número de líneas de un fichero
#---------------------------------------------------------------------


text_file = sc.textFile("hdfs://sandbox:8020/user/rhadoop/bigiris.txt")

num_lineas = text_file.count()
num_lineas


#---------------------------------------------------------------------
# número categorías en un fichero
#---------------------------------------------------------------------


counts = text_file.map(lambda line: line.split("\t")[4]) \
             .map(lambda word: (word, 1)) \
             .reduceByKey(lambda a, b: a + b)

counts.take(10)

# Ejercicio: escribe el proceso anterior con un único map.



#---------------------------------------------------------------------
# clústering
#---------------------------------------------------------------------

from pyspark.mllib.clustering import KMeans, KMeansModel
from numpy import array, where
from math import sqrt

datos = text_file.map(lambda line: array([float(x) for x in line.split("\t")[0:4]]))
clusters = KMeans.train(datos, 4, maxIterations=10, runs=10, initializationMode="random")


def predecir(punto, centros):
    diferencias = [centro - punto for centro in centros]
    distancias  = array([sqrt(sum(diferencia**2)) for diferencia in diferencias])
    return where(distancias==distancias.min())[0][0]
        
    

def error(punto):
    centro = clusters.centers[predecir(punto, clusters.centers)]
    return sqrt(sum([x**2 for x in (punto - centro)]))


WSSSE = datos.map(lambda punto: error(punto)).reduce(lambda x, y: x + y)
print("La suma de distancias de los puntos a sus centros es = " + str(WSSSE))


# Ejercicio: calcula la distancia promedio de cada punto a su centro (por centro).

# Ejercicio: calcula el WSSSE para varios números de centros. ¿Hay un codo en la gráfica?


def procesa_linea(linea):
    tmp = linea.split("\t")
    especie = tmp[4]
    valores = array([float(x) for x in tmp[0:4]])
    return (especie, valores)


datos_especies = text_file.map(procesa_linea) \
    .map(lambda x: (x[0], predecir(x[1], clusters.centers)))\
    .map(lambda x: (x, 1)).reduceByKey(lambda a, b: a + b)



#---------------------------------------------------------------------
# regresión lineal
#---------------------------------------------------------------------

from pyspark.mllib.regression import LabeledPoint, LinearRegressionWithSGD

# Carga de los datos (se convierten en un LabelledPoint)
def parsePoint(line):
    values = [float(x) for x in line.replace(',', ' ').split(' ')]
    return LabeledPoint(values[4], values[0:4])

data = sc.textFile("hdfs://sandbox:8020/user/rhadoop/banknote.txt")
parsedData = data.map(parsePoint)

# Build the model
model = LinearRegressionWithSGD.train(parsedData)

# Evaluación del modelo
valuesAndPreds = parsedData.map(lambda p: (p.label, model.predict(p.features)))
MSE = valuesAndPreds.map(lambda (v, p): (v - p)**2).reduce(lambda x, y: x + y) / valuesAndPreds.count()
print("Mean Squared Error = " + str(MSE))



#---------------------------------------------------------------------
# regresión logística con banknotes
#---------------------------------------------------------------------

# Queda propuesta como ejercicio modificando la anterior




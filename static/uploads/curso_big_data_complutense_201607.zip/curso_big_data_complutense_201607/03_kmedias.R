#######################################################################
# cjgb, 20160621
# map reduce implementar el algoritmo de kmedias
#######################################################################

library(rmr2)

#----------------------------------------------------------------------
# definición del conjunto de entrada
#----------------------------------------------------------------------

# definimos el tipo de fichero que es: de texto, separado por tabuladores

fnam <- "/user/rhadoop/bigiris.txt"              # nombre
fif  <- make.input.format("csv", sep = "\t")     # formato


# seleccionamos unos centros (4) al "azar":

centros <- as.matrix(iris[1:3, 1:4])


# definimos el map
# el map va a encontrar para cada observación, el id de su centro más próximo

centro.mas.proximo <- function(fila){
  tmp <- apply(centros, 1, function(x) sum((x - fila)^2))
  which.min(tmp)
}

my.map <- function(k,v){ 
  tmp <- as.matrix(v[, 1:4])
  mas.proximo <- apply(tmp, 1, centro.mas.proximo)
  keyval(mas.proximo, v) 
}


# El reduce encuentra el valor medio de los puntos asociados a cada nuevo centro

my.reduce <- function(k,v){
  keyval(k, list(colMeans(v[, 1:4])))
}


res <- mapreduce(
  input = fnam,
  input.format = fif,
  map = my.map,
  reduce = my.reduce)


# Extraemos los centros

res.r <- from.dfs(res)
nuevos.centros <- do.call(rbind, res.r$val)


# Ejercicio: iterar n veces el proceso anterior hasta encontrar "buenos centros"





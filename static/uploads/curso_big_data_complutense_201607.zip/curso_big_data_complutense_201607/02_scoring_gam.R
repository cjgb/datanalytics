#######################################################################
# cjgb, 201607
# scoring
#######################################################################

library(mgcv)
library(ggplot2)

#####################################################
# simulate data
#####################################################

n <- 10000 
dat <- gamSim(1, n=n, dist="binary", scale=.33)

#####################################################
# fit a gam model
#####################################################

lr.fit <- gam(y ~ s(x0, bs="cr") + s(x1, bs="cr") + s(x2, bs="cr") + s(x3, bs="cr"),
              family=binomial, data=dat, method="REML")


#####################################################
# save it and remove everything
#####################################################

save(lr.fit, file = "/tmp/gam_model.RData")
rm(list=ls())

#####################################################
# generate new set of data on hadoop 
# (our scoring problem!)
#####################################################

n <- 100000
dat <- gamSim(1, n=n, dist="binary", scale=.33)
write.table(dat, file = "/tmp/borrar_cjgb.txt", col.names = F, row.names = F, sep = "\t")
system("hadoop fs -put /tmp/borrar_cjgb.txt to_be_gam_scored.txt")
system("hadoop fs -ls /user/rhadoop")
rm(dat, n)

#####################################################
# prepare for scoring
#####################################################

load("/tmp/gam_model.RData")

fnam <- "/user/rhadoop/to_be_gam_scored.txt"
fif  <- make.input.format("csv", sep = "\t")

outfnam <- "/user/rhadoop/gam_scored"
outff   <- make.output.format("csv", sep = "\t")

my.score <- function(k,v){
  colnames(v) <- c("y", "x0", "x1", "x2", "x3", "f", "f0", "f1", "f2", "f3")
  res <- predict(lr.fit, newdata = v, type = "response")
  v$res <- res
  keyval(1, v)
}

#####################################################
# scoring!
#####################################################

mapreduce(
  input = fnam,
  input.format = fif,
  output = outfnam,
  output.format = outff,
  map = my.score
)


#####################################################
# browse the results
#####################################################

res <- read.table(pipe("hadoop fs -cat gam_scored/*"), header = F, sep = "\t")
colnames(res) <- c("key", "y", "x0", "x1", "x2", "x3", "f", "f0", "f1", "f2", "f3", "prob")

# with boxplots
boxplot(res$prob ~ factor(res$y), col = "gray")

# or perhaps fancier...
ggplot(res, aes(x=prob, fill=factor(y))) + geom_density(alpha=.3)


#####################################################
# cleanup
#####################################################

system("hadoop fs -rmr gam_scored to_be_gam_scored.txt")
rm(list = ls()); gc()


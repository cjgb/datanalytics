#######################################################################
# cjgb, 20160621
# map reduce para explorar el fichero de microdatos de la encuesta de
# estructura salarial
#######################################################################

library(rmr2)

#----------------------------------------------------------------------
# conteos de filas
#----------------------------------------------------------------------

# definimos el tipo de fichero que es: de texto, separado por tabuladores

fnam <- "/user/rhadoop/ess2010.csv"              # nombre
fif  <- make.input.format("csv", sep = "\t")     # formato

# definimos el map

my.map <- function(k,v){ 
  keyval(1, nrow(v)) 
}

# mapreduce! (sin reduce)

res <- mapreduce(
  input = fnam,
  input.format = fif,
  map = my.map)


# res (resultado para los amigos) "vive" en hadoop. Pero queremos traerlo a R para analizar sus contenidos: 
res.r <- from.dfs(res)

# Ejercicio: el objeto resultante es una lista con dos componentes: ¡explóralas!


# definimos el reduce

my.reduce <- function(k,v){
  keyval(1, sum(v))
}


res <- mapreduce(
  input = fnam,
  input.format = fif,
  map = my.map,
  reduce = my.reduce)

res.r <- from.dfs(res)


#----------------------------------------------------------------------
# agregaciones simples
#----------------------------------------------------------------------

nombres.columnas <-
  c("ordenccc", "ordentra", "nuts1", "cnace", "estrato2", "control", 
    "mercado", "regulacion", "sexo", "tipopais", "cno1", "responsa", 
    "estu", "anoanti", "mesanti", "tipojor", "tipocon", "fijodism", 
    "fijodisd", "val", "van", "puentes", "jap", "jsp1", "jsp2", "hextra", 
    "drelabm", "siespm1", "dsiespm1", "siespm2", "dsiespm2", "salbase", 
    "extraorm", "phextra", "comsal", "comsaltt", "irpfmes", "cotiza", 
    "base", "drelabam", "drelabad", "siespa1", "dsiespa1", "siespa2", 
    "dsiespa2", "siespa3", "dsiespa3", "siespa4", "dsiespa4", "salbruto", 
    "gextra", "vesp", "anos2", "factotal")



my.map <- function(k,v){ 
  colnames(v) <- nombres.columnas
  keyval(v$sexo, v$factotal) 
}

# mapreduce! (sin reduce)

res <- mapreduce(
  input = fnam,
  input.format = fif,
  map = my.map)


res.r <- from.dfs(res)

# Ejercicio: vuelve a explorar los contenidos del objeto resultante


# definimos el reduce

my.reduce <- function(k,v){
  keyval(k, sum(v))
}


res <- mapreduce(
  input = fnam,
  input.format = fif,
  map = my.map,
  reduce = my.reduce)

res.r <- from.dfs(res)



# Ejercicio: mejora el algoritmo anterior preagregando en los maps: en lugar de pasarle al reduce una 
#    observación por fila, pásale el número de hombres y mujeres de cada bloque


#----------------------------------------------------------------------
# agregaciones más complejas
#----------------------------------------------------------------------

library(plyr)

my.map <- function(k,v){ 
  colnames(v) <- nombres.columnas
  tmp <- ddply(v, .(sexo, estu), summarize, total = sum(factotal))
  keyval(cbind(as.character(tmp$sexo), as.character(tmp$estu)), tmp$total) 
}

# mapreduce! (sin reduce)

res <- mapreduce(
  input = fnam,
  input.format = fif,
  map = my.map)


res.r <- from.dfs(res)

# Ejercicio: vuelve a explorar los contenidos del objeto resultante, crea un único df con todo y 
#    obtén el agregado final

# Ejercicio: haz lo anterior usando un reduce


#----------------------------------------------------------------------
# agregaciones más complejas
#----------------------------------------------------------------------

# Calcula el salario bruto (salbruto) medio de las mujeres y los hombres. 

# Calcula el salario bruto (salbruto) medio de las mujeres y los hombres por niveles educativos.

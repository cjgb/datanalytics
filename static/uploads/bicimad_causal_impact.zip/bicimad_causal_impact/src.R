#################################################################################
# @gilbellosta, 2017-05-29
# Estudio causal del impacto de la remunicipalización de BiciMad en el número de 
#   usos del servicio. Motivado por
#   http://www.eldiario.es/desde-mi-bici/sexto-mes-BiciMAD-municipalizada-resucito_6_647845233.html
#################################################################################

library(zoo)
library(xts)
library(CausalImpact)

# los datos se descargan de la página de datos abiertos del Ayto. de Madrid
# están en excel y exportados a csv

bicis <- read.table("bici_usos_acumulados201703.csv", header = T, sep = ",")

bicis <- bicis[, c("DIA", "Usos.bicis.total")]
colnames(bicis) <- c("fecha", "usos")

bicis$fecha <- as.Date(bicis$fecha, format = "%m/%d/%Y")
bicis$usos <- as.numeric(gsub(",", "", bicis$usos))

tmp <- zoo(bicis$usos, order.by = bicis$fecha)
tmp <- tmp[!is.na(tmp)]

plot(xts(tmp), ylab = "número de usos", main = "BiciMad: usos del servicio")
abline(v = as.POSIXct(as.Date("2016-09-26")), col = "red", lty = 2)

# descargamos datos de temperatura y precipitación diarios 
# de https://www.ncdc.noaa.gov/cdo-web/
# para Madrid

temperaturas <- read.csv("978541.csv")
temperaturas <- temperaturas[temperaturas$STATION_NAME == "MADRID BARAJAS SP",]

temperaturas$PRCP[temperaturas$PRCP < -1000] <- 0
temperaturas$TAVG[temperaturas$TAVG < -1000] <- median(temperaturas$TAVG)

temperaturas <- temperaturas[, c("DATE", "PRCP", "TAVG")]
colnames(temperaturas) <- c("fecha", "precipitacion", "temperatura")
temperaturas$fecha <- as.Date(as.character(temperaturas$fecha), format = "%Y%m%d")

datos <- merge(bicis, temperaturas)
datos <- datos[!is.na(datos$usos),]

# añadimos una variable indicadora del día de la semana (lunes...)
datos <- cbind(datos, contrasts(factor(weekdays(datos$fecha, abbreviate = TRUE)), contrasts = FALSE))

# causal impact
pre.period  <- c(min(datos$fecha), as.Date("2016-09-26"))
post.period <- c(as.Date("2016-09-27"), max(datos$fecha))

# filtramos el primer año, que tiene un comportamiento creciente y "anómalo"
tmp <- datos[datos$fecha > as.Date("2015-01-01"),]
tmp <- zoo(tmp[,-1], order.by = datos$fecha)

impact <- CausalImpact(tmp, pre.period, post.period)
plot(impact)

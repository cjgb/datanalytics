############################################################################################
# @gilbellosta, 2018-11-28
# Modelización de los datos usando caret + xgboost
############################################################################################

library(caret)
library(party)
library(xgboost)

rents <- read.table("data/rent.txt", header = TRUE, sep = "\t", fileEncoding = "latin1")

## modelo simple (árboles)

tmp <- rents
tmp$Rent.per.sqm <- NULL

modelo.ctree.0 <- ctree(Rent ~ ., data = tmp, controls = )

tmp$preds <- predict(modelo.ctree.0)
plot(tmp$Rent, tmp$preds)
abline(lm(preds ~ Rent, data = tmp), col = "red")

plot(modelo.ctree.0)


## modelo simple (árboles)
## ahora, usando el aquiler por m2 como variable objetivo

tmp <- rents
tmp$Rent <- NULL

modelo.ctree.1 <- ctree(Rent.per.sqm ~ ., data = tmp, controls = )

tmp$preds <- predict(modelo.ctree.0)
plot(tmp$Rent.per.sqm, tmp$preds)
abline(lm(preds ~ Rent.per.sqm, data = tmp), col = "red")

plot(modelo.ctree.1)


#-------------------------------------------------------------------------------------------
# Modelización de los datos usando caret + xgboost
#-------------------------------------------------------------------------------------------

tmp <- rents
tmp$Rent <- NULL
tmp$District.No. <- NULL

# primero, indicamos que queremos usar validación cruzada
trctrl <- trainControl(method = "cv", number = 5)


## parámetros por tipo de modelo: http://topepo.github.io/caret/train-models-by-tag.html

tune_grid <- expand.grid(nrounds = c(100, 200, 300, 400), 
                        max_depth = c(3:7),
                        eta = c(0.05, 1),
                        gamma = c(0.01),
                        colsample_bytree = c(0.75),
                        subsample = c(0.50),
                        min_child_weight = c(0))

rf_fit <- train(Rent.per.sqm ~., 
                data = tmp, 
                method = "xgbTree",
                trControl=trctrl,
                tuneGrid = tune_grid)

# inspección de los resultados
rf_fit

plot(rf_fit)

# los parámetros del mejor modelo
rf_fit$bestTune


modelo_final <- rf_fit$finalModel

tmp$preds <- predict(rf_fit, newdata = tmp)


plot(tmp$Rent.per.sqm, tmp$preds)
abline(lm(preds ~ Rent.per.sqm, data = tmp), col = "red")






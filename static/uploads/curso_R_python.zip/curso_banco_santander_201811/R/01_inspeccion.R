############################################################################################
# @gilbellosta, 2018-11-28
# Inspección de un conjunto de datos (para su análisis posterior)
############################################################################################

# lectura de datos
rents <- read.table("data/rent.txt", header = TRUE, sep = "\t")

# inspección básica del conjunto de datos
head(rents)
dim(rents)
summary(rents)

# comprobaciones de datos
table(rents$District, rents$District.No.)

head(rents$Rent.per.sqm)
head(rents$Rent / rents$Size)
plot(rents$Rent.per.sqm, rents$Rent / rents$Size)


## un modelo sencillo
## nota: frecuentemente, un modelo sencillo es útil para inspeccionar datos

plot(rents$Size, rents$Rent)
modelo.lm <- lm(Rent ~ Size, data = rents)
abline(modelo.lm, col = "red")
summary(modelo.lm)

plot(modelo.lm$residuals, rents$Built)


# análisis visual

library(ggplot2)

ggplot(rents, aes(x = Size, y = Rent, col = Built)) + geom_point(alpha = 0.3)

ggplot(rents, aes(x = Size, y = Rent, col = Built)) + 
  geom_point(alpha = 0.3) + 
  facet_wrap(~ District)


ggplot(rents, aes(x = Size, y = Rent, col = Built)) + 
  geom_point(alpha = 0.3) + 
  geom_smooth(method = "lm", col = "red", alpha = 0.5) +
  facet_wrap(~ District)


ggplot(rents, aes(x = Built, y = Rent.per.sqm)) + 
  geom_point(alpha = 0.3) + 
  geom_smooth(method = "lm", col = "red", alpha = 0.5) +
  facet_wrap(~ District)




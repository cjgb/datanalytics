library(micromap)
library(tidyr)
library(pxR)
library(ggrepel)
library(extrafont)
library(scales)

raw <- readOGR(dsn=".",layer = "se89_3_admin_prov_a_x")

raw1 <- read.px("3996.px")
datos <- as.data.frame(raw1)

datos$id_prov <- as.factor(separate(datos, Provincias, "id_prov", " ")$id_prov)
datos <- datos[order(datos$id_prov),]

provPolys <- create_map_table(raw, IDcolumn = "id_prov")

the_font <- "Calibri"
theme_set(theme_minimal(base_family = the_font))

lmplot(stat.data = datos,
       map.data = provPolys,
       panel.types = c('labels', 'dot','map'),
       panel.data = list('Provincias','value', NA),
       ord.by = 'value', 
       rev.prd = TRUE,
       grouping = 5,
       colors = brewer.pal(5, "Spectral"),
       median.row = FALSE,
       # how to merge the two data frames:
       map.link = c('id_prov', 'ID'),
       # stroke colour of the borders of previously-drawn areas:
       map.color2 = "white",
       # how to save the result:
       #print.file = "0095-eg1.png",
       #print.res = 600,
       #plot.width = 7,
       #plot.height = 9,
       # attributes of the panels:
       panel.att = list(
         list(1, header = "Provincias", 
              panel.width = 0.8,
              text.size = 0.8, 
              align = 'right', 
              panel.header.font = the_font,
              panel.header.face = "bold",
              text.font = the_font,
              left.margin = 2,
              right.margin = 1),
         list(2, header = "Tasa paro", 
              xaxis.title = 'porcentaje',
              xaxis.ticks = list(10, 15, 20, 25,30),
              xaxis.labels = list(10, 15, 20, 25,30),
              graph.bgcolor = 'lightblue',
              graph.grid.color = "grey99",
              graph.border.color = "white", 
              panel.header.font = the_font,
              panel.header.face = "bold"),
         list(3, header = 'Mapa', 
              panel.width = 0.8,
              panel.header.font = the_font,
              panel.header.face = "bold")
       ))


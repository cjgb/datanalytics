######################################################################################
# @gilbellosta, 2017-04-15
# Recencia y frecuencia usando el modelo Pareto/NBD
# Basado en https://cran.r-project.org/web/packages/BTYD/vignettes/BTYD-walkthrough.pdf
######################################################################################

library(BTYD)

# carga de datos brutos

cdnowElog <- system.file("data/cdnowElog.csv", package = "BTYD")
elog <- dc.ReadLines(cdnowElog, cust.idx = 2, date.idx = 3, sales.idx = 5)
elog$date <- as.Date(elog$date, "%Y%m%d")

# realmente, casi todo lo que hacemos a continuación es redundante: solo necesitamos
# construir el objeto cal.cbs debajo (que podemos hacer de otras maneras y sin usar
# estas funciones)

elog <- dc.MergeTransactionsOnSameDate(elog)

end.of.cal.period <- as.Date("1997-09-30")
elog.cal <- elog[which(elog$date <= end.of.cal.period), ]

split.data <- dc.SplitUpElogForRepeatTrans(elog.cal)

clean.elog <- split.data$repeat.trans.elog

freq.cbt <- dc.CreateFreqCBT(clean.elog)
freq.cbt[1:3,1:5]


tot.cbt <- dc.CreateFreqCBT(elog)
cal.cbt <- dc.MergeCustomers(tot.cbt, freq.cbt)


birth.periods <- split.data$cust.data$birth.per
last.dates <- split.data$cust.data$last.date
cal.cbs.dates <- data.frame(birth.periods, last.dates,
                            end.of.cal.period)
cal.cbs <- dc.BuildCBSFromCBTAndDates(cal.cbt, cal.cbs.dates, per="week")

#--------------------------------------------------------------------------
# Ahora ya tenemos los datos necesarios
# Procedemos al ajuste
#--------------------------------------------------------------------------

params <- pnbd.EstimateParameters(cal.cbs)
params

# estos son r, alpha, s y beta

# Exploración de las distribuciones

pnbd.PlotTransactionRateHeterogeneity(params)
pnbd.PlotDropoutRateHeterogeneity(params)




# Aplicación a un nuevo usuario (del que no se tiene información)
# Esto calcula el número esperado de compras en 52 semanas:
pnbd.Expectation(params, t = 52)

# A continuación, calculamos la misma esperanza para un usuario
# del que conocemos cierta información:
cal.cbs["1516",]
x <- cal.cbs["1516", "x"]
t.x <- cal.cbs["1516", "t.x"]
T.cal <- cal.cbs["1516", "T.cal"]
pnbd.ConditionalExpectedTransactions(params, T.star = 52, x, t.x, T.cal)

pnbd.PAlive(params, x, t.x, T.cal)


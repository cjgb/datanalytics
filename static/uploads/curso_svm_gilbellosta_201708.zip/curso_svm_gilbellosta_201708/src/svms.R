#############################################################################
# cgb@datanalytics.com, 2017-08-21
#
# Material para las sesiones sobre SVM
#############################################################################

#----------------------------------------------------------------------------
# separabilidad y regresión logística
#----------------------------------------------------------------------------

set.seed(1234)

# vamos a construir un conjunto de datos _separados_

n <- 50
clase.1 <- data.frame(clase = 1, 
                      x = rnorm(n, 2, 1),
                      y = rnorm(n, 2, 1))
clase.0 <- data.frame(clase = 0, 
                      x = rnorm(n, -2, 1),
                      y = rnorm(n, -2, 1))
datos <- rbind(clase.0, clase.1)

plot(datos$x, datos$y, col = datos$clase + 2,
     xlab = "x", ylab = "y",
     main = "Datos separados")

# un posible plano _separador_
abline(0, -1, col = "gray")

# el modelo logístico no converge
# ¡debería dar un error!
modelo <- glm(clase ~ x + y, datos, family = binomial)

# en realidad, los coeficientes de x e y en el modelo deberían tender a infinito
coef(modelo)

# porque el modelo logístico nos daría probabilidad 0 (exactamente 0) en una región 
# y 1 (exactamente 1) en otra


# Ejercicio: el hiperplano representado mediante abline(0, -1, col = "gray") tiene ecuación
# x + y = 0. Comprueba numéricamente que las clases están en subespacios distintos.

# Ejercicio: calcula la distancia de cada punto al hiperplano.


#----------------------------------------------------------------------------
# svm y separabilidad
#----------------------------------------------------------------------------

library(e1071)
library(ggplot2)

tmp <- datos
tmp$clase <- factor(tmp$clase)

mod.svm <- svm(clase ~ x + y, data = tmp, 
               cost = 1000, 
               scale = FALSE,
               kernel = "linear")

# comparamos la predicción con los valores reales
table(tmp$clase, predict(mod.svm))

# el gráfico es un poco... feo
plot(mod.svm, tmp)

# vamos a construir otro más atractivo

# primero, vamos a marcar las zonas que divide el hiperplano
grid_x <- seq(min(datos$x) - 0.5, max(datos$x) + 0.5, by = 0.05)
grid_y <- seq(min(datos$y) - 0.5, max(datos$y) + 0.5, by = 0.05)
my_grid <- expand.grid(grid_x, grid_y)
colnames(my_grid) <- c("x", "y")
my_grid$pred <- predict(mod.svm, my_grid)

base <- ggplot(my_grid, aes(x = x, y = y, col = pred)) +
  geom_point(size = 0.1, alpha = 0.3) +
  guides(col = FALSE) +
  theme_bw()

base

# representamos los datos originales
grf <- base + geom_point(aes(x = x, y = y, col = factor(clase)), data = datos)
grf  

# marcamos los puntos base (del margen)
tmp <- mod.svm$index
tmp <- datos[tmp,]
grf <- grf + geom_point(aes(x = x, y = y), data = tmp, col = "black", alpha = 0.2, size = 4)
grf

# extraemos el hiperplano y el margen
beta  <- t(mod.svm$coefs) %*% mod.svm$SV
beta0 <- mod.svm$rho

grf <- grf + geom_abline(intercept = beta0/beta[2], slope = -beta[1]/beta[2], col = "gray50") +
  geom_abline(intercept = (beta0 - 1)/beta[2], slope = -beta[1]/beta[2], col = "gray50", linetype = "dotted") + 
  geom_abline(intercept = (beta0 + 1)/beta[2], slope = -beta[1]/beta[2], col = "gray50", linetype = "dotted")
  
grf


#----------------------------------------------------------------------------
# svm y costes
#----------------------------------------------------------------------------

# creamos datos artificiales no linealmente separables

set.seed(1234)

clase.1 <- data.frame(clase = 1, 
                      x = rnorm(n, 1, 1),
                      y = rnorm(n, 1, 1))
clase.0 <- data.frame(clase = 0, 
                      x = rnorm(n, -1, 1),
                      y = rnorm(n, -1, 1))
datos <- rbind(clase.0, clase.1)
datos$clase <- factor(datos$clase)

# los representamos
plot(datos$x, datos$y, col = datos$clase)
abline(0, -1, col = "gray")

# usamos un coste (¡no es C!) muy pequeño
mod.svm <- svm(clase ~ x + y, data = datos, 
               cost = 0.01, 
               scale = FALSE,
               kernel = "linear")

# inspección del modelo
summary(mod.svm)


# primero, vamos a marcar las zonas que divide el hiperplano
grid_x <- seq(min(datos$x) - 0.5, max(datos$x) + 0.5, by = 0.05)
grid_y <- seq(min(datos$y) - 0.5, max(datos$y) + 0.5, by = 0.05)
my_grid <- expand.grid(grid_x, grid_y)
colnames(my_grid) <- c("x", "y")
my_grid$pred <- predict(mod.svm, my_grid)

base <- ggplot(my_grid, aes(x = x, y = y, col = pred)) +
  geom_point(size = 0.1, alpha = 0.3) +
  guides(col = FALSE) +
  theme_bw()

# representamos los datos originales
grf <- base + geom_point(aes(x = x, y = y, col = factor(clase)), data = datos)

# marcamos los puntos base (del margen)
tmp <- mod.svm$index
tmp <- datos[tmp,]
grf <- grf + geom_point(aes(x = x, y = y), data = tmp, col = "black", alpha = 0.2, size = 4)

# extraemos el hiperplano y el margen
beta  <- t(mod.svm$coefs) %*% mod.svm$SV
beta0 <- mod.svm$rho

grf <- grf + geom_abline(intercept = beta0/beta[2], slope = -beta[1]/beta[2], col = "gray50") +
  geom_abline(intercept = (beta0 - 1)/beta[2], slope = -beta[1]/beta[2], col = "gray50", linetype = "dotted") + 
  geom_abline(intercept = (beta0 + 1)/beta[2], slope = -beta[1]/beta[2], col = "gray50", linetype = "dotted")

grf

# Ejercicio:
# Practicad y usad otros costes distintos para ver cómo varían los vectores de soporte



#----------------------------------------------------------------------------
# svm y selección de costes
#----------------------------------------------------------------------------

# vamos a usar la función `tune` de e1071 para encontrar el coste "óptimo" (mediante cv)
set.seed(1234)

res <- tune(svm, clase ~ x + y, data = datos, 
            kernel = "linear", scale = FALSE,
            ranges = list(cost = c(0.001, 0.01, 0.1, 1, 5,10, 100)))

summary(res)

# Ejercicio
# Analizar gráficamente el caso "óptimo"
# Pista: puedes usar como modelo el que da res$best.model


# Ejercicio
# Utiliza tune para encontrar el mejor modelo usando los datos separables de más arriba


# Ejercicio
# Crea dos conjuntos de datos (no separables) con la misma estructura. Crea el modelo óptimo y luego
# usa predict para crear la matriz de confusión correspondiente.


# Ejercicio
# Compara el mejor modelo usando la técnica anterior con el construido usando regresión logística.




#----------------------------------------------------------------------------
# svm y expansión de variables
#----------------------------------------------------------------------------

# vamos a crear datos no separables, unos "dentro" de los otros
set.seed(1234)
n <- 50

clase.1 <- data.frame(clase = 1, 
                      x = rnorm(n),
                      y = rnorm(n))
clase.0 <- data.frame(clase = 0, 
                      x = rnorm(n * 1000, 0, 3),
                      y = rnorm(n * 1000, 0, 3))
clase.0$dist <- sqrt(clase.0$x^2 + clase.0$y^2)
clase.0 <- head(clase.0[clase.0$dist > 2 & clase.0$dist < 4, 
                        c("clase", "x", "y")], n)

datos <- rbind(clase.0, clase.1)
datos$clase <- factor(datos$clase)

# representación gráfica
plot(datos$x, datos$y, col = datos$clase,
     xlab = "x", ylab = "y")


# Ejercicio
# Probad el svm anterior... ¿qué sale?


# Extensión de la dimensión
datos$xy <- datos$x * datos$y
datos$x2 <- datos$x^2
datos$y2 <- datos$y^2


# usamos un coste (¡no es C!) muy pequeño
mod.svm <- svm(clase ~ ., data = datos, 
               cost = 20, 
               scale = FALSE,
               kernel = "linear")

# inspección del modelo
summary(mod.svm)


# primero, vamos a marcar las zonas que divide el hiperplano
grid_x <- seq(min(datos$x) - 0.5, max(datos$x) + 0.5, by = 0.05)
grid_y <- seq(min(datos$y) - 0.5, max(datos$y) + 0.5, by = 0.05)
my_grid <- expand.grid(grid_x, grid_y)
colnames(my_grid) <- c("x", "y")
my_grid <- transform(my_grid,
                     xy = x * y,
                     x2 = x^2,
                     y2 = y^2)

my_grid$pred <- predict(mod.svm, my_grid)

base <- ggplot(my_grid, aes(x = x, y = y, col = pred)) +
  geom_point(size = 0.1, alpha = 0.3) +
  guides(col = FALSE) +
  theme_bw()

# representamos los datos originales
grf <- base + geom_point(aes(x = x, y = y, col = factor(clase)), data = datos)

# marcamos los puntos base (del margen)
tmp <- mod.svm$index
tmp <- datos[tmp,]
grf <- grf + geom_point(aes(x = x, y = y), data = tmp, col = "black", alpha = 0.2, size = 4)

grf


# comparación con el modelo logístico
mod.logistic <- glm(clase ~ ., data = datos, family = binomial)

my_grid$pred_logistic <- predict(mod.logistic, my_grid, type = "response")
my_grid$pred_logistic <- my_grid$pred_logistic > 0.5

ggplot(my_grid, aes(x = x, y = y, col = pred_logistic > 0)) +
  geom_point(size = 0.1, alpha = 0.3) +
  geom_point(aes(x = x, y = y, col = factor(clase)), data = datos) +
  guides(col = FALSE) +
  theme_bw()


# Ejercicio
# El problema anterior también puede resolverse añadiendo una única variable adicional. ¿Cómo?


#----------------------------------------------------------------------------
# svm y kernels
#----------------------------------------------------------------------------

set.seed(1234)
n <- 50

clase.1 <- data.frame(clase = 1, 
                      x = rnorm(n),
                      y = rnorm(n))
clase.0 <- data.frame(clase = 0, 
                      x = rnorm(n * 1000, 0, 3),
                      y = rnorm(n * 1000, 0, 3))
clase.0$dist <- sqrt(clase.0$x^2 + clase.0$y^2)
clase.0 <- head(clase.0[clase.0$dist > 2 & clase.0$dist < 4, 
                        c("clase", "x", "y")], n)

datos <- rbind(clase.0, clase.1)
datos$clase <- factor(datos$clase)


# usamos un coste (¡no es C!) muy pequeño
mod.svm <- svm(clase ~ ., data = datos, 
               cost = 20, 
               scale = FALSE,
               kernel = "polynomial",
               degree = 2)

# inspección del modelo
summary(mod.svm)


grid_x <- seq(min(datos$x) - 0.5, max(datos$x) + 0.5, by = 0.05)
grid_y <- seq(min(datos$y) - 0.5, max(datos$y) + 0.5, by = 0.05)
my_grid <- expand.grid(grid_x, grid_y)
colnames(my_grid) <- c("x", "y")


my_grid$pred <- predict(mod.svm, my_grid)

base <- ggplot(my_grid, aes(x = x, y = y, col = pred)) +
  geom_point(size = 0.1, alpha = 0.3) +
  guides(col = FALSE) +
  theme_bw()

# representamos los datos originales
grf <- base + geom_point(aes(x = x, y = y, col = factor(clase)), data = datos)

# marcamos los puntos base (del margen)
tmp <- mod.svm$index
tmp <- datos[tmp,]
grf <- grf + geom_point(aes(x = x, y = y), data = tmp, col = "black", alpha = 0.2, size = 4)

grf


# Ejercicio
# Prueba con otros grados y kernels

# Ejercicio
# Usa `tune` para identificar el coste óptimo; representa gráficamente el modelo

# Ejercicio
# Usa `tune` para identificar el la combinación de coste y grado óptimos

# Ejercicio
# Usa otros kernels y tune para encontrar el parámetro óptimo


#----------------------------------------------------------------------------
# svm y caret
#----------------------------------------------------------------------------

library(caret)

train.control <- trainControl(method = "cv", number = 10)
grid <- expand.grid(degree = 1:5, 
                    scale = 1:3,
                    C = c(0.1, 0.3, 0.5, 1, 10, 100))
model.svm <- train(as.character(clase) ~ ., data = datos, 
                   trControl = train.control, 
                   tuneGrid = grid,
                   method = "svmPoly")

# resumen de los resultados
print(model.svm)
plot(model.svm)


# Ejercicio: 
# Afina la selección del modelo restringiendo la búsqueda de parámetros al área de interés


# Ejercicio
# Usa el conjunto de datos `data/data_banknote_authentication.txt` para entrenar un modelo que distinga
# billetes verdaderos de falsos. Busca el mejor modelo. Prueba a escalar y no escalar las variables.

# Ejercicios: crear modelos para predecir las variables objetivo de alguno de estos
#   conjuntos de datos:
#   - https://archive.ics.uci.edu/ml/datasets/Bike+Sharing+Dataset (regresión)
#   - https://archive.ics.uci.edu/ml/datasets/Bank+Marketing (clasificación)
#   - https://archive.ics.uci.edu/ml/datasets/default+of+credit+card+clients (clasificación)
#   - https://archive.ics.uci.edu/ml/datasets/Wine+Quality (regresión)



library(png)
m <- readPNG("/tmp/firma.png")

x <- col(m)
y <- row(m)
firma <- matrix(0, nrow(m), ncol(m))
firma[m > 0.9] <- 1

#firma <- matrix(bw, nrow(m), ncol(m))
plot(1:2, type='n')
rasterImage(firma, 1, 1, 2, 2)

datos.orig <- data.frame(firma = factor(as.numeric(firma)), x = as.numeric(x), y = as.numeric(y))

datos <- datos.orig[datos.orig$firma == "0", c("x", "y")]

modelo <- svm(datos, type = 'one-classification', scale = FALSE)

res <- datos
res$pred <- predict(modelo, datos)
res <- res[res$pred,]


plot(datos$x, -datos$y)
plot(res$x, -res$y)


imagen <- matrix(1, nrow(m), ncol(m))
tmp <- cbind(res$y, res$x)
imagen[tmp] <- 0

plot(1:2, type = 'n')
rasterImage(imagen, 1, 1, 2, 2)




curve(dbeta(x, 2, 3), 0, 1)
curve(dbeta(x, 1, 1), 0, 1)
curve(dbeta(x, 2, 1), 0, 1)
curve(dbeta(x, 2, 2), 0, 1)

curve(dbeta(x, 41, 31), 0, 1)

curve(dbeta(x, 101, 121), 0, 1)


curve(dbeta(x, 2, 1), 0, 1)
curve(dbeta(x, 1, 1), 0, 1, col = "red", add = T)

muestra.1 <- rbeta(1e5, 2, 1)
muestra.2 <- rbeta(1e5, 1, 1)

res <- data.frame(a1 = muestra.1, a2 = muestra.2)

mean(muestra.1 > muestra.2)




##################################################
# cjgb, 20101026
# construye un fichero en formato MSProject con 
#	los tiempos de ejecuci�n de los wf
##################################################

# El objetivo del ejercicio es leer el fichero ej01_in.txt y convertirlo en uno similar a ej01_out_example.txt

# El fichero de entrada tiene seis columnas, de las que vamos a utilizar las siguientes:
#   malla, un proceso de carga de datos
#   wf, uno de los "workflows" en que se divide una malla
#   start, fecha/hora de inicio de la ejecuci�n del wf
#   end, fecha/hora de fin de la ejecuci�n del wf

# Estos datos han sido proporcionados por un sistema de logs de ejecuciones en un servidor.
# Queremos transformarlos en un fichero que pueda ser importado por MS Project para su representaci�n gr�fica

# El fichero de salida tiene las siguientes columnas (posiblemente otras que ignoraremos)
#   wf, discutido m�s abajo
#   start, fecha/hora de inicio del wf
#   timespan, duraci�n del wf con el formato "xxx mins", donde xxx es un entero
#   level, el nivel, que es 1, 2 o 3 (v�ase abajo)

# Hay tres niveles, 1, 2 y 3. 
# En las filas donde el nivel es 1 el wf es la fecha en formato YYYY-MM-DD y los dem�s campos, menos el nivel, son nulos/vac�os
# En las filas donde el nivel es 2 el wf es la malla y los dem�s campos, menos el nivel, son nulos/vac�os
# En el resto de las filas (nivel 3) aparecen todos los campos (nombre del wf, start, timespan, level)

# Debajo de una l�nea de nivel 2, hay un bloque de l�neas de nivel 3 que corresponden a los wf de la malla correspondiente ordenados por el campo start
# Debajo de una l�nea de nivel 1 aparecen bloques como los anteriores ordenados por el m�nimo valor de "start" del bloque

# Los bloques de nivel 1 (fechas) tienen que estar ordenados

# Conceptualmente:

#   Fecha 1
#       malla 1
#           wf 1.1
#           wf 1.2
#       malla 2
#           wf 2.1
#           wf 2.2
#           wf 2.3
#   Fecha 2
#       malla 1
#           wf 1.1
#           wf 1.2
#       malla 2
#           wf 2.1
#           wf 2.2
#           wf 2.3


## Carga de las librer�as

source( "00.R" )


## Formato M$project

proj <- read.table( "dat/ej01_in.txt", head = T, sep = "\t" )

proj <- transform( proj, start = as.POSIXct( strptime( start, "%d/%m/%Y %H:%M:%S") ) )
proj <- transform( proj, end   = as.POSIXct( strptime( end,   "%d/%m/%Y %H:%M:%S") ) )

proj <- transform( proj, 
            timespan = as.numeric( difftime( end, start, units = "mins" ) ), 
            level = 3, 
            date = as.Date( as.POSIXlt( start ) ) 
        )

proj <- transform( proj, timespan = paste( round( timespan ), "mins", sep = " " ) )

proj <- subset( proj, select = c( malla, wf, start, timespan, level, date ) )

proj <- ddply( proj, 
               .( date, malla ), 
               function( x ) data.frame( x, min.time = min( x$start  ) )
        )


foo <- function( x ){
	wf.date <- unique( as.character( x$date ) )

	foo.malla <- function ( x ) {
			x <- x[ order( x$start ), ]
            x <- subset( x, select = -date )
			rbind( data.frame( malla = "", wf = unique( x$malla ), start = as.POSIXct(NA), timespan = "", level = 2, min.time = NA ), x )
	}

	x <- ddply( x, .( min.time, malla ), foo.malla )
	rbind( data.frame( malla = "", wf = wf.date , start = as.POSIXct(NA), timespan = "", level = 1, min.time = NA ), x )
}

proj <- ddply( proj, .( date ), foo )

proj <- subset( proj, select = -c(malla, min.time, date) )

write.table( proj, file = "ej01_out.txt", col.names = T, row.names = F, sep = ";", na = "", dec = "," ) 


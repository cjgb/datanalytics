##############################################################################
# cjgb, 20101115
# introducci�n a ggplot2
##############################################################################

source( "00.R" )

###############################################
# Ejemplo 1: gr�ficos de uso de CPU con qplot
###############################################

dat   <- read.table( "dat/uso_cpu.csv", header = T, sep = ";", dec = ",")
dat.m <- melt( dat, id = "hora" )

# transforma un factor en su representaci�n interna
# �peligroso!

dat.m <- transform( dat.m, hora = as.numeric( hora ) )	

# Primeros gr�ficos
qplot( hora, value, data = dat.m, geom = "line", facets = variable ~ . )
qplot( hora, value, data = dat.m, geom = "line", facets = . ~ variable )

# Podemos guardar un gr�fico...
p <- qplot( hora, value, data = dat.m, geom = "line", facets = variable ~ . )

# ... en disco como un fichero .png (u otros)...
ggsave( "mi_primer_grafico.png", p )

# ... o como un objeto de R
save( p, file = "mi_primer_grafico.Rdat" )

rm( p )
load( "mi_primer_grafico.Rdat" )
p

# Otros geom
qplot( factor( hora ), weight=value, data = dat.m, geom = "histogram", facets = . ~ variable )
qplot( factor( hora ), weight=value, data = dat.m, geom = "histogram", facets = variable ~ . )
qplot( factor( hora ), weight=value, data = dat.m, geom = "bar", facets = . ~ variable )

################################################
# Ejemplo 2: Est�ticas
################################################

tmp <- data.frame( x = 1:3, y = 1:3, colour = 1:3 )
p <- ggplot( tmp, aes( x, y, colour = colour ) ) + geom_point()
p

ggsave( "aes.eps", p )

p <- ggplot( tmp, aes( x, y, shape = colour ) ) + geom_point()
p

p <- p + aes( x, y, colour = colour )

summary( p )

################################################
# Ejemplo 3: Geometr�as
################################################

p <- ggplot( tmp, aes( x, y, colour = colour ) ) + geom_line()
p
ggsave( "geom.eps", p )


p <- ggplot( dat.m ) + aes( factor( hora ), weight=value ) 
p <- p + geom_histogram( fill = "blue" )
p

p <- p + geom_bar( fill = "red" ) 
p <- p + opts(title = "Mi t�tulo" )
p

p <- ggplot( dat.m ) + aes( hora, value ) 
p <- p + geom_path()
p

################################################
# Ejemplo 4: Facetas
################################################


p <- ggplot( data = dat.m ) + geom_line()
p <- p + aes( hora, value )
p
summary( p )

p.col <- p + facet_grid( variable ~ . )
p.col

p.row <- p + facet_grid( variable ~ . )
p.row


################################################
# Ejemplo 4: Layers
################################################

n <- 100
x <- 2 * 3 * runif( n )
tmp <- data.frame( x = x, y = sin( x ) + rnorm( n, sd = 0.2 ) )

p.1 <- qplot( x, y, data = tmp )
p.1 
summary( p.1 )

p.2 <- ggplot( data = tmp ) + aes( x, y ) + geom_smooth()
p.2


p <- p.1 + geom_smooth()
p




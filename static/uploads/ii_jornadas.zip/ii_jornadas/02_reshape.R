##############################################################################
# cjgb, 20101110
# introducción al paquete reshape
##############################################################################

source( "00.R" )

#############################################
# Ejemplo 1: melt (ejemplo sencillo)
#############################################

iris.m <- melt( iris )

# alternativas:

iris.m <- melt( iris, id.vars = "Species" )
iris.m <- melt( iris, id.vars = 5 )

iris.m <- melt( iris, id.vars = "Species", measure.vars = 1:4 )
iris.m <- melt( iris, id.vars = 5, measure.vars = 1:4 )


#############################################
# Ejemplo 2: melt (ejemplo sencillo)
#############################################

data( Produc )

produc.m <- melt( Produc )	# no da el resultado deseado: queremos que year 
				# sea tambi�n una variable "id"

produc.m <- melt( Produc, id = c("state", "year") )


#############################################
# Ejemplo 3: melt (datos de panel)
#############################################

econ   <- read.table( "dat/econ.csv", header = T, sep = ";", dec = "," )
econ.m <- melt( econ, id = c("pais", "cod", "region", "ano" ) )


#############################################
# Ejemplo 4: cast
#############################################

table.iris.1 <- cast( iris.m, Species ~ variable )
table.iris.1 <- cast( iris.m, Species ~ variable, lenght )	# lo mismo

table.iris.2 <- cast( iris.m, Species ~ variable, mean )


#############################################
# Ejemplo 5: cast
#############################################

cast( econ.m, ano ~ pais )
cast( econ.m, ~ variable, function(x) any( is.na(x) ) )

#############################################
# Ejercicio 1: melt y nulos
#############################################

# estudiar el comportamiento de melt con nulos y las alternativas que existen


#############################################
# Temas para profundizar
#############################################

# 1) El comportamiento de melt con nulos




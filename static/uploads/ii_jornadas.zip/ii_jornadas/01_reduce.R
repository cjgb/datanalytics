##############################################################################
# cjgb, 20101109
# introducción a la función Reduce
##############################################################################


#############################################
# Ejemplo 1: vectorizar una función
#############################################

f <- function( x, y ) ifelse( x > y, x, y )
v <- rnorm( 100 )

Reduce( f, v )

# El ejemplo 1 no es particularmente ilustrativo porque la función max ya 
# está vectorizada.

max( v )


#############################################
# Ejemplo 2: fracciones continuas
#############################################

f <- function( x, y ) y + 1 / x
v <- rep( 1, 12 )

Reduce( f, v, accumulate = T )

# Ejercicio: definir
#   f(x, y) = x + 1 / y
# y probar Reduce con la opción "right = T/F"


#############################################
# Ejemplo 3: Tiempos de espera en colas
#############################################

n <- 10000      # n periodos de 1 minuto

lambda1 <- .3   # intensidad de las llegadas
lambda2 <- .4   # intensidad del tiempo de servicio

events <- data.frame(  
    entrada = rpois( n, lambda1 ),
    salida  = rpois( n, lambda2 )
    )

# Convertimos el df en una lista por minutos

events <- by( events, 1:n, I )     

calcular.longitud.cola <- function( long.cola, delta ){
    max( 0, long.cola + delta$entrada - delta$salida )
}

# hour.events <- Reduce( estado.cola, events, init = 0 )

longitud.cola <- Reduce( calcular.longitud.cola, events, init = 0, accumulate = T )

plot( longitud.cola, type = "l" )


#############################################
# Ejercicio 1: vectorizar cbind y rbind
#############################################

# creamos una lista de dfs

lista.df <- sapply( 1:4, function(x) head( iris ), simplify = F )

# ejercicio: usar Reduce y cbind/rbind para colapsar la lista en un único df

# comparar el resultado con:

do.call( rbind, lista.df )
do.call( cbind, lista.df )


#############################################
# Ejercicio 2: iteraciones y fractales
#############################################

# ir a 
#  http://www.datanalytics.com/blog/2010/10/26/a-vueltas-con-los-fractales/
# y reescribir el código que aparece usando Reduce para obtener el mismo resultado


#############################################
# Ejercicio 3: ?Reshape
#############################################

# consultar ?Reshape y ver qué otras funciones "funcionales" existen en R



##############################################################################
# cjgb, 20101109
# carga de paquetes necesarios para el taller de las II jornadas de 
#       usuarios de R
##############################################################################

library( plyr )
library( reshape )
library( ggplot2 )
library( plm )
library( foreach )
library( doMC )



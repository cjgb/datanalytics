##############################################################################
# cjgb, 20101114
# introducci�n al paquete plyr
##############################################################################

source( "00.R" )

#############################################
# Ejemplo 1: 
#############################################

# �Mal!
ddply( iris, .(Species), mean )             

# Mucho mejor
ddply( iris, .(Species), colwise( mean, is.numeric ) )             

ddply( iris, .(Species), colwise( length, is.factor ) )             

## adl_

laply( iris, class )
ldply( iris, class )
llply( iris, class )
l_ply( iris, function( x ) print( paste( "Es un ", class( x ), sep = "" ) )  )


#############################################
# Ejemplo 2: paralelismo
#############################################

# No hacer nada durante 4 segundos
Sys.sleep( 4 )

# No hacer nada durante un segundo 4 veces seguidas
system.time( ldply( rep(1, 4), Sys.sleep) )

# Introducimeos paralelismo
registerDoMC( cores = 2 )
system.time( ldply( rep(1, 4), Sys.sleep, .parallel = T) )



#############################################
# Ejercicio 1: un caso m�s complicado (y real)
#############################################

# analizar el fichero 03_02_plyr_extra.R


#############################################
# Temas para profundizar
#############################################

# Correr los ejercicios de ayuda de alguna de las funciones auxiliares del 
#   paquete plyr




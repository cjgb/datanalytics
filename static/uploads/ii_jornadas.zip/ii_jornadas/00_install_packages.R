##############################################################################
# cjgb, 20101109
# carga de paquetes necesarios para el taller de las II jornadas de 
#       usuarios de R
##############################################################################

install.packages( "plyr" )
install.packages( "reshape" )
install.packages( "ggplot2" )
install.packages( "plm" )
install.packages( "foreach" )

# No Windows!
install.packages( "doMC" )



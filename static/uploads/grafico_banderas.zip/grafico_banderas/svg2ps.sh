#!/bin/bash

inkscape Flag_of_Austria.svg --export-eps=Flag_of_Austria.eps --export-text-to-path
inkscape Flag_of_Belgium.svg --export-eps=Flag_of_Belgium.eps --export-text-to-path
inkscape Flag_of_Bulgaria.svg --export-eps=Flag_of_Bulgaria.eps --export-text-to-path
inkscape Flag_of_Cyprus.svg --export-eps=Flag_of_Cyprus.eps --export-text-to-path
inkscape Flag_of_Estonia.svg --export-eps=Flag_of_Estonia.eps --export-text-to-path
inkscape Flag_of_Finland.svg --export-eps=Flag_of_Finland.eps --export-text-to-path
inkscape Flag_of_France.svg --export-eps=Flag_of_France.eps --export-text-to-path
inkscape Flag_of_Germany.svg --export-eps=Flag_of_Germany.eps --export-text-to-path
inkscape Flag_of_Greece.svg --export-eps=Flag_of_Greece.eps --export-text-to-path
inkscape Flag_of_Hungary.svg --export-eps=Flag_of_Hungary.eps --export-text-to-path
inkscape Flag_of_Ireland.svg --export-eps=Flag_of_Ireland.eps --export-text-to-path
inkscape Flag_of_Italy.svg --export-eps=Flag_of_Italy.eps --export-text-to-path
inkscape Flag_of_Latvia.svg --export-eps=Flag_of_Latvia.eps --export-text-to-path
inkscape Flag_of_Lithuania.svg --export-eps=Flag_of_Lithuania.eps --export-text-to-path
inkscape Flag_of_Luxembourg.svg --export-eps=Flag_of_Luxembourg.eps --export-text-to-path
inkscape Flag_of_Malta.svg --export-eps=Flag_of_Malta.eps --export-text-to-path
inkscape Flag_of_Poland.svg --export-eps=Flag_of_Poland.eps --export-text-to-path
inkscape Flag_of_Portugal.svg --export-eps=Flag_of_Portugal.eps --export-text-to-path
inkscape Flag_of_Romania.svg --export-eps=Flag_of_Romania.eps --export-text-to-path
inkscape Flag_of_Slovakia.svg --export-eps=Flag_of_Slovakia.eps --export-text-to-path
inkscape Flag_of_Slovenia.svg --export-eps=Flag_of_Slovenia.eps --export-text-to-path
inkscape Flag_of_Spain.svg --export-eps=Flag_of_Spain.eps --export-text-to-path
inkscape Flag_of_Sweden.svg --export-eps=Flag_of_Sweden.eps --export-text-to-path
inkscape Flag_of_the_Czech_Republic.svg --export-eps=Flag_of_the_Czech_Republic.eps --export-text-to-path
inkscape Flag_of_the_Netherlands.svg --export-eps=Flag_of_the_Netherlands.eps --export-text-to-path
inkscape Flag_of_the_United_Kingdom.svg --export-eps=Flag_of_the_United_Kingdom.eps --export-text-to-path


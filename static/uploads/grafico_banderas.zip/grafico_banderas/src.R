library( grImport )
library( lattice )


PostScriptTrace("Flag_of_Austria.eps")
PostScriptTrace("Flag_of_Belgium.eps")
PostScriptTrace("Flag_of_Bulgaria.eps")
PostScriptTrace("Flag_of_Cyprus.eps")
PostScriptTrace("Flag_of_Estonia.eps")
PostScriptTrace("Flag_of_Finland.eps")
PostScriptTrace("Flag_of_France.eps")
PostScriptTrace("Flag_of_Germany.eps")
PostScriptTrace("Flag_of_Greece.eps")
PostScriptTrace("Flag_of_Hungary.eps")
PostScriptTrace("Flag_of_Ireland.eps")
PostScriptTrace("Flag_of_Italy.eps")
PostScriptTrace("Flag_of_Latvia.eps")
PostScriptTrace("Flag_of_Lithuania.eps")
PostScriptTrace("Flag_of_Luxembourg.eps")
PostScriptTrace("Flag_of_Malta.eps")
PostScriptTrace("Flag_of_Poland.eps")
PostScriptTrace("Flag_of_Portugal.eps")
PostScriptTrace("Flag_of_Romania.eps")
PostScriptTrace("Flag_of_Slovakia.eps")
PostScriptTrace("Flag_of_Slovenia.eps")
PostScriptTrace("Flag_of_Spain.eps")
PostScriptTrace("Flag_of_Sweden.eps")
PostScriptTrace("Flag_of_the_Czech_Republic.eps")
PostScriptTrace("Flag_of_the_Netherlands.eps")
PostScriptTrace("Flag_of_the_United_Kingdom.eps")

aut <- readPicture("Flag_of_Austria.eps.xml")
bel <- readPicture("Flag_of_Belgium.eps.xml")
bgr <- readPicture("Flag_of_Bulgaria.eps.xml")
cyp <- readPicture("Flag_of_Cyprus.eps.xml")
est <- readPicture("Flag_of_Estonia.eps.xml")
fin <- readPicture("Flag_of_Finland.eps.xml")
fra <- readPicture("Flag_of_France.eps.xml")
deu <- readPicture("Flag_of_Germany.eps.xml")
grc <- readPicture("Flag_of_Greece.eps.xml")
hun <- readPicture("Flag_of_Hungary.eps.xml")
irl <- readPicture("Flag_of_Ireland.eps.xml")
ita <- readPicture("Flag_of_Italy.eps.xml")
lva <- readPicture("Flag_of_Latvia.eps.xml")
ltu <- readPicture("Flag_of_Lithuania.eps.xml")
lux <- readPicture("Flag_of_Luxembourg.eps.xml")
mlt <- readPicture("Flag_of_Malta.eps.xml")
pol <- readPicture("Flag_of_Poland.eps.xml")
prt <- readPicture("Flag_of_Portugal.eps.xml")
rom <- readPicture("Flag_of_Romania.eps.xml")
svk <- readPicture("Flag_of_Slovakia.eps.xml")
svn <- readPicture("Flag_of_Slovenia.eps.xml")
esp <- readPicture("Flag_of_Spain.eps.xml")
swe <- readPicture("Flag_of_Sweden.eps.xml")
cze <- readPicture("Flag_of_the_Czech_Republic.eps.xml")
ndl <- readPicture("Flag_of_the_Netherlands.eps.xml")
gbr <- readPicture("Flag_of_the_United_Kingdom.eps.xml")


dat <- read.table( "funcionarios_eur.txt", header = T, sep = "\t" )

dat <- subset( dat, pais != "lux" )

#plot( dat$func_pct, dat$ppa, type = "n", xlab = "% funcionarios", ylab = "renta per cápita", font = 2, font.lab = 2)

#title( "Funcionarios y renta per cápita", font.main = 2 )

#text( dat$func_pct, dat$ppa, labels = dat$pais )

#dat.ger <- subset( dat, pais %in% c("grb", "aut", "deu", "ndl", "irl" ) )
#abline( lm( ppa ~ func_pct , data = dat.ger ), col = "blue" )

#dat.lat <- subset( dat, pais %in% c("cze", "grc", "esp", "ita", "bel", "fra", "fin", "swe" ) )
#abline( lm( ppa ~ func_pct, data = dat.lat ), col = "blue" )

png( "funcionarios_bandera.png" )

xyplot( ppa ~ func_pct, 
        groups = pais, 
        data = dat, 
        xlab = "% funcionarios", ylab = "renta per cápita",
        main = "Funcionarios y renta per cápita",
        panel = function( x, y, subscripts, groups, col ){
                panel.fill( col = "gray" )
                for( i in 1:length( groups[subscripts] ) ){
                    symbol <- get( as.character( groups[subscripts][i] ) )
                    grid.symbols( symbol, x[i], y[i], units = "native", size = unit( 5, "mm" ) )
                }
        }
)

dev.off()


